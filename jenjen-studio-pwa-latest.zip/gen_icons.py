#!/usr/bin/env python3
"""從主圖重新產生 JenJen Studio PWA 圖示組。

用法：pip install pillow && python gen_icons.py
輸入：放在本檔案旁邊的 jenjen-icon-master.png（已核准的 JenJen 主圖）
輸出：./icons/（192、512、maskable 512、apple-touch-icon 180、favicon 32）

maskable 圖示會把主圖縮到 80% 置中，保留 Android 裁切安全區；
其餘圖示為滿版（四角以主圖角落的夜色補滿，不留白邊）。
"""
from pathlib import Path
from PIL import Image

HERE = Path(__file__).parent
MASTER = HERE / "jenjen-icon-master.png"
OUT = HERE / "icons"
OUT.mkdir(exist_ok=True)


def full_bleed(master):
    """主圖若帶圓角白邊，以角落夜色補滿成滿版方圖。"""
    w, h = master.size
    # 以四角平均色當作背景色（JenJen 主圖四角皆為深藍夜色）
    corners = [master.getpixel(p) for p in
               [(0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)]]
    bg = tuple(sum(c[i] for c in corners) // 4 for i in range(3))
    if master.mode != "RGB":
        master = master.convert("RGB")
    # 接近純白的像素視為圓角外的留白，換成夜色
    px = master.load()
    base = Image.new("RGB", (w, h), bg)
    bp = base.load()
    for y in range(h):
        for x in range(w):
            r, g, b = px[x, y]
            bp[x, y] = bg if (r > 245 and g > 245 and b > 245) else (r, g, b)
    return base, bg


def main():
    if not MASTER.exists():
        raise SystemExit(f"找不到主圖：{MASTER}，請先把核准的 JenJen 主圖放在本檔案旁邊。")
    master = Image.open(MASTER).convert("RGB")
    full, bg = full_bleed(master)

    def save(img, name):
        img.save(OUT / name)
        print("✓", name, f"{img.width}x{img.height}")

    for size, name in [(512, "icon-512.png"), (192, "icon-192.png"),
                       (180, "apple-touch-icon.png"), (32, "favicon-32.png")]:
        save(full.resize((size, size), Image.LANCZOS), name)

    # maskable：80% 置中，保留安全區
    m = Image.new("RGB", (512, 512), bg)
    art = full.resize((410, 410), Image.LANCZOS)
    m.paste(art, ((512 - 410) // 2, (512 - 410) // 2))
    save(m, "icon-maskable-512.png")
    print("完成，圖示已輸出到", OUT)


if __name__ == "__main__":
    main()
